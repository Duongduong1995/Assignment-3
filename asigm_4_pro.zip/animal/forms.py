from cmd import IDENTCHARS
from unicodedata import name
from django import forms

def check_size(value):
    if len(value) < 2:
        raise forms.ValidationError("the Name is too short")

class Signup(forms.Form):
    # id = forms.AutoField(primary_key=True)
    name = forms.CharField(initial = 'Name', validators=[check_size, ])
    age = forms.IntegerField(required = False)
    color = forms.CharField(help_text = "write animal's color", required = False)
