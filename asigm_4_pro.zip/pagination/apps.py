from django.apps import AppConfig


class PaginationConfig(AppConfig):
    name = 'pagination'
